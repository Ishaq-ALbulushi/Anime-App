import generateAnime from "./generateAnime";
import "./styles/main.scss";
import anime from "./assets/anime.webp";
const animes = document.getElementById("animes");
animes.src = anime;
const jokeBtn=document.getElementById('jokeBtn')
jokeBtn.addEventListener('click',generateAnime)
generateAnime();
